package com.salesianostriana.bookclub.model;

public enum Estado {
    ACTIVO,DEVUELTO
}
