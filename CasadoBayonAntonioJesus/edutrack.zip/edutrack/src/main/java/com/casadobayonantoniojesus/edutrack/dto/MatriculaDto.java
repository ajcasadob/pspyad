package com.casadobayonantoniojesus.edutrack.dto;

public record MatriculaDto() {
}
