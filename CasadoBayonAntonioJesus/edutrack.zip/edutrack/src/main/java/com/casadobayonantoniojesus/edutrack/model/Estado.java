package com.casadobayonantoniojesus.edutrack.model;

public enum Estado {

    MATRICULADO, APROBADO, SUSPENSO
}
