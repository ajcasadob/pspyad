package com.casadobayonantoniojesus.edutrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdutrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
